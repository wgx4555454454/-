#pragma once
#include <iostream>
#include <string>
#include <cstring>
#include <fstream>
#include"role.h"

using namespace std;
const int FULL_hp = 100;
const int FULL_mp = 100;

class Enemy {
public:
	Role _enemy[7] = { Role(100,40,30),Role(100,40,30) ,Role(100,40,30) ,Role(100,40,30) ,Role(100,40,30) ,Role(100,40,30) ,Role(100,40,30) };
	void Setenemy_information() {};
};

